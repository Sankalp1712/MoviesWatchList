export interface Movie{
    id:number,
    name:string,
    year:number,
    url:string,
    rating:number,
   about:string

}