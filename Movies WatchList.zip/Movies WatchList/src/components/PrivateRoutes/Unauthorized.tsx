import React from 'react'
const Unauthorized:React.FC = () => {
  return (
    <div>
        <h3>Unauthorized</h3>
    </div>
  )
}

export default Unauthorized